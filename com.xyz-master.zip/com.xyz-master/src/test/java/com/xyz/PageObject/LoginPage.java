package com.xyz.PageObject;

public class LoginPage {

}
